package vn.quan.trolyquan.domain.model

/**
 * Thông tin ứng dụng thực tế đã cài đặt trên thiết bị của người dùng,
 * được quét trực tiếp từ Android PackageManager.
 */
data class InstalledAppInfo(
    val appName: String,
    val packageName: String,
    val normalizedSearchName: String,
    val isSystemApp: Boolean
)

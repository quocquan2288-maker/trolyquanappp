package vn.quan.trolyquan.domain.model

/**
 * Trạng thái trực quan của Trợ Lý Quân, điều khiển màu sắc vòng cầu năng lượng,
 * sóng âm thanh và thông báo trạng thái trên thanh Header.
 */
enum class AssistantState(
    val statusLabel: String,
    val subtitleHint: String,
    val primaryHex: Long,
    val secondaryHex: Long
) {
    IDLE(
        statusLabel = "ĐANG RẢNH • SẴN SÀNG",
        subtitleHint = "Bấm giữ hoặc chạm nút Micro để gọi Quân, hoặc gõ lệnh bên dưới",
        primaryHex = 0xFF00F5D4,   // Neon Cyan
        secondaryHex = 0xFF7B2CBF  // Electric Violet
    ),
    LISTENING(
        statusLabel = "ĐANG NGHE ANH EM NÓI...",
        subtitleHint = "Nói to, rõ tiếng Việt nhé (VD: "Mở TikTok", "Bật đèn pin")",
        primaryHex = 0xFF00BBF9,   // Bright Sky Blue
        secondaryHex = 0xFF00F5D4  // Neon Cyan
    ),
    THINKING(
        statusLabel = "QUÂN ĐANG VẮT ÓC XỬ LÝ...",
        subtitleHint = "Đợi tí, đang phân tích câu lệnh và kiểm tra hệ thống",
        primaryHex = 0xFF9D4EDD,   // Vivid Purple
        secondaryHex = 0xFFF72585  // Neon Magenta
    ),
    EXECUTING(
        statusLabel = "ĐANG ĐIỀU KHIỂN ĐIỆN THOẠI",
        subtitleHint = "Đang gọi Android Intent & API phần cứng thật",
        primaryHex = 0xFFFF9E00,   // Hot Amber
        secondaryHex = 0xFFFF007F  // Electric Rose
    ),
    SPEAKING(
        statusLabel = "QUÂN ĐANG TRẢ LỜI...",
        subtitleHint = "Chạm vào nút Micro bất kỳ lúc nào để ngắt lời Quân",
        primaryHex = 0xFF06D6A0,   // Emerald Neon
        secondaryHex = 0xFF118AB2  // Deep Ocean Cyan
    ),
    ERROR(
        statusLabel = "ĐANG CÁU • CÓ LỖI XẢY RA",
        subtitleHint = "Kiểm tra lại quyền truy cập, kết nối mạng hoặc câu lệnh",
        primaryHex = 0xFFFF2A85,   // Crimson Neon
        secondaryHex = 0xFFFF6B00  // Flame Orange
    )
}

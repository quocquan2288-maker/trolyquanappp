package vn.quan.trolyquan.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import vn.quan.trolyquan.domain.model.AiProviderType
import vn.quan.trolyquan.domain.model.AssistantState
import vn.quan.trolyquan.domain.model.ChatMessage
import vn.quan.trolyquan.domain.model.CommandType
import vn.quan.trolyquan.domain.model.InstalledAppInfo
import vn.quan.trolyquan.domain.model.MessageSender
import vn.quan.trolyquan.domain.model.SystemCommand
import vn.quan.trolyquan.ui.components.NeonOrbVisualizer
import vn.quan.trolyquan.ui.theme.CrimsonAlert
import vn.quan.trolyquan.ui.theme.DeepSpaceSurface
import vn.quan.trolyquan.ui.theme.ElectricViolet
import vn.quan.trolyquan.ui.theme.EmeraldSuccess
import vn.quan.trolyquan.ui.theme.GlassBorderSubtle
import vn.quan.trolyquan.ui.theme.GlassCardBg
import vn.quan.trolyquan.ui.theme.GlassCardElevated
import vn.quan.trolyquan.ui.theme.HotAmber
import vn.quan.trolyquan.ui.theme.NeonCyan
import vn.quan.trolyquan.ui.theme.NeonSky
import vn.quan.trolyquan.ui.theme.ObsidianBg
import vn.quan.trolyquan.ui.theme.TextMuted
import vn.quan.trolyquan.ui.theme.TextPrimary
import vn.quan.trolyquan.ui.theme.TextSecondary

enum class MainTab(val title: String) {
    ASSISTANT("Trợ Lý Quân"),
    APPS("Ứng Dụng"),
    SETTINGS("Cài Đặt AI"),
    DIAGNOSTICS("Trạng Thái")
}

@Composable
fun MainAssistantScreen(
    uiState: QuanUiState,
    hasAudioPermission: Boolean,
    hasCameraPermission: Boolean,
    hasCallPermission: Boolean,
    onRequestPermissions: () -> Unit,
    onMicOrOrbClick: () -> Unit,
    onStopSpeaking: () -> Unit,
    onSendMessage: (String) -> Unit,
    onSpeakMessage: (String) -> Unit,
    onToggleTorch: () -> Unit,
    onToggleVoiceAutoSpeak: () -> Unit,
    onClearHistory: () -> Unit,
    onRefreshApps: () -> Unit,
    onLaunchApp: (InstalledAppInfo) -> Unit,
    onExecuteDirectCommand: (SystemCommand) -> Unit,
    onSaveSettings: (vn.quan.trolyquan.domain.model.AiSettings) -> Unit,
    onConfirmSensitiveAction: () -> Unit,
    onCancelSensitiveAction: () -> Unit,
    onDismissBanner: () -> Unit
) {
    var selectedTabIndex by rememberSaveable { mutableIntStateOf(0) }
    val tabs = MainTab.entries

    // Hộp thoại xác nhận đối với tác vụ nhạy cảm (VD: Gọi điện thoại)
    if (uiState.pendingConfirmationCommand != null) {
        AlertDialog(
            onDismissRequest = onCancelSensitiveAction,
            containerColor = GlassCardElevated,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = HotAmber
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Xác nhận thao tác nhạy cảm",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            },
            text = {
                Text(
                    text = "${uiState.pendingConfirmationDescription}

Quân không bao giờ tự ý thực hiện tác vụ nhạy cảm khi đại ca chưa chốt!",
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = onConfirmSensitiveAction,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = ObsidianBg)
                ) {
                    Text("Xác nhận thực hiện", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = onCancelSensitiveAction) {
                    Text("Hủy bỏ", color = CrimsonAlert)
                }
            }
        )
    }

    Scaffold(
        containerColor = ObsidianBg,
        topBar = {
            QuanGlassTopBar(
                state = uiState.assistantState,
                isTorchOn = uiState.isTorchOn,
                voiceAutoSpeak = uiState.settings.voiceAutoSpeak,
                onToggleTorch = onToggleTorch,
                onToggleVoiceAutoSpeak = onToggleVoiceAutoSpeak,
                onClearHistory = onClearHistory
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = DeepSpaceSurface,
                tonalElevation = 8.dp
            ) {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        icon = {
                            val icon = when (tab) {
                                MainTab.ASSISTANT -> Icons.Default.GraphicEq
                                MainTab.APPS -> Icons.Default.Apps
                                MainTab.SETTINGS -> Icons.Default.Tune
                                MainTab.DIAGNOSTICS -> Icons.Default.Security
                            }
                            Icon(imageVector = icon, contentDescription = tab.title)
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 11.sp,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ObsidianBg,
                            selectedTextColor = NeonCyan,
                            indicatorColor = NeonCyan,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            ObsidianBg,
                            DeepSpaceSurface,
                            ObsidianBg
                        )
                    )
                )
                .padding(innerPadding)
        ) {
            when (tabs[selectedTabIndex]) {
                MainTab.ASSISTANT -> AssistantConversationTab(
                    uiState = uiState,
                    onMicOrOrbClick = onMicOrOrbClick,
                    onStopSpeaking = onStopSpeaking,
                    onSendMessage = onSendMessage,
                    onSpeakMessage = onSpeakMessage,
                    onDismissBanner = onDismissBanner
                )
                MainTab.APPS -> InstalledAppsTab(
                    apps = uiState.installedApps,
                    isScanning = uiState.isScanningApps,
                    onRefresh = onRefreshApps,
                    onLaunchApp = onLaunchApp
                )
                MainTab.SETTINGS -> AiAndVoiceSettingsTab(
                    settings = uiState.settings,
                    availableVoices = uiState.availableVietnameseVoices,
                    selectedVoiceSummary = uiState.selectedVoiceSummary,
                    onSaveSettings = onSaveSettings,
                    onTestSpeak = {
                        onSpeakMessage(
                            "Alo 1 2 3 4! Tôi là Quân đây, giọng đọc tiếng Việt thế này đã đủ trầm ấm và uy tín chưa đại ca?"
                        )
                    }
                )
                MainTab.DIAGNOSTICS -> SystemDiagnosticsTab(
                    uiState = uiState,
                    hasAudioPermission = hasAudioPermission,
                    hasCameraPermission = hasCameraPermission,
                    hasCallPermission = hasCallPermission,
                    onRequestPermissions = onRequestPermissions,
                    onExecuteDirectCommand = onExecuteDirectCommand
                )
            }
        }
    }
}

@Composable
private fun QuanGlassTopBar(
    state: AssistantState,
    isTorchOn: Boolean,
    voiceAutoSpeak: Boolean,
    onToggleTorch: () -> Unit,
    onToggleVoiceAutoSpeak: () -> Unit,
    onClearHistory: () -> Unit
) {
    val badgeColor by animateColorAsState(
        targetValue = Color(state.primaryHex),
        animationSpec = tween(400),
        label = "topbar_badge_color"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DeepSpaceSurface.copy(alpha = 0.92f))
            .border(width = 0.5.dp, color = GlassBorderSubtle)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(badgeColor)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "TRỢ LÝ QUÂN",
                    color = TextPrimary,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 16.sp,
                    letterSpacing = 1.sp
                )
                Text(
                    text = state.statusLabel,
                    color = badgeColor,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            // Nút bật/tắt đèn pin trực tiếp trên thanh trạng thái
            IconButton(onClick = onToggleTorch) {
                Icon(
                    imageVector = if (isTorchOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
                    contentDescription = "Bật/Tắt đèn pin",
                    tint = if (isTorchOn) HotAmber else TextSecondary
                )
            }

            // Nút bật/tắt tự động đọc giọng nói
            IconButton(onClick = onToggleVoiceAutoSpeak) {
                Icon(
                    imageVector = if (voiceAutoSpeak) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                    contentDescription = "Bật/Tắt đọc tiếng",
                    tint = if (voiceAutoSpeak) NeonCyan else TextMuted
                )
            }

            // Nút dọn lịch sử hội thoại
            IconButton(onClick = onClearHistory) {
                Icon(
                    imageVector = Icons.Default.DeleteSweep,
                    contentDescription = "Xóa lịch sử",
                    tint = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun AssistantConversationTab(
    uiState: QuanUiState,
    onMicOrOrbClick: () -> Unit,
    onStopSpeaking: () -> Unit,
    onSendMessage: (String) -> Unit,
    onSpeakMessage: (String) -> Unit,
    onDismissBanner: () -> Unit
) {
    var inputText by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    val focusManager = LocalFocusManager.current

    LaunchedEffect(uiState.messages.size) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.size - 1)
        }
    }

    val quickCommands = listOf(
        "Mở TikTok",
        "Mở YouTube",
        "Mở Chrome",
        "Bật đèn pin",
        "Tắt đèn pin",
        "Tăng âm lượng",
        "Giảm âm lượng",
        "Mở Cài đặt",
        "Mở Wi-Fi"
    )

    Column(modifier = Modifier.fillMaxSize()) {
        // Banner thông báo lỗi hoặc chẩn đoán (nếu có)
        AnimatedVisibility(visible = !uiState.lastDiagnosticBanner.isNullOrBlank()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(CrimsonAlert.copy(alpha = 0.16f))
                    .border(1.dp, CrimsonAlert.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.ErrorOutline,
                    contentDescription = null,
                    tint = CrimsonAlert,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = uiState.lastDiagnosticBanner.orEmpty(),
                    color = TextPrimary,
                    fontSize = 12.sp,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onDismissBanner, modifier = Modifier.size(24.dp)) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Đóng",
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // Khu vực Quả cầu năng lượng Neon + Sóng âm thanh sống động
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 6.dp, bottom = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            NeonOrbVisualizer(
                state = uiState.assistantState,
                audioAmplitude = uiState.audioAmplitude,
                orbSize = 152.dp,
                onOrbClick = onMicOrOrbClick
            )

            Text(
                text = uiState.partialSpeechText.ifBlank { uiState.assistantState.subtitleHint },
                color = if (uiState.partialSpeechText.isNotBlank()) NeonCyan else TextSecondary,
                fontSize = 12.sp,
                fontWeight = if (uiState.partialSpeechText.isNotBlank()) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.padding(horizontal = 20.dp)
            )

            if (uiState.isSpeaking) {
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedButton(
                    onClick = onStopSpeaking,
                    shape = RoundedCornerShape(50),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.StopCircle,
                        contentDescription = null,
                        tint = CrimsonAlert,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Ngắt lời Quân", color = CrimsonAlert, fontSize = 11.sp)
                }
            }
        }

        // Danh sách lịch sử hội thoại
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(items = uiState.messages, key = { it.id }) { msg ->
                ChatMessageBubble(
                    message = msg,
                    onReplayVoice = { onSpeakMessage(msg.text) }
                )
            }
        }

        // Dải nút gợi ý lệnh điều khiển nhanh
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            quickCommands.forEach { cmdText ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(GlassCardBg)
                        .border(1.dp, NeonCyan.copy(alpha = 0.35f), RoundedCornerShape(50))
                        .clickable { onSendMessage(cmdText) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = cmdText,
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Thanh điều khiển phía dưới: Nút Micro lớn + Ô nhập văn bản + Nút Gửi
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DeepSpaceSurface)
                .border(0.5.dp, GlassBorderSubtle)
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Nút Micro lớn có viền phát sáng theo trạng thái nghe
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = if (uiState.isListening) {
                                listOf(CrimsonAlert, HotAmber)
                            } else {
                                listOf(NeonCyan, ElectricViolet)
                            }
                        )
                    )
                    .clickable { onMicOrOrbClick() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (uiState.isListening) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Micro giọng nói",
                    tint = ObsidianBg,
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = {
                    Text(
                        text = "Nhắn hoặc ra lệnh cho Quân (VD: Mở TikTok)...",
                        fontSize = 13.sp,
                        color = TextMuted
                    )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (inputText.isNotBlank()) {
                            onSendMessage(inputText)
                            inputText = ""
                            focusManager.clearFocus()
                        }
                    }
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = GlassCardBg,
                    unfocusedContainerColor = GlassCardBg,
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = GlassBorderSubtle
                ),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.weight(1f)
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (inputText.isNotBlank()) {
                        onSendMessage(inputText)
                        inputText = ""
                        focusManager.clearFocus()
                    }
                },
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(NeonCyan.copy(alpha = 0.18f))
                    .border(1.dp, NeonCyan.copy(alpha = 0.6f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Gửi lệnh",
                    tint = NeonCyan
                )
            }
        }
    }
}

@Composable
private fun ChatMessageBubble(
    message: ChatMessage,
    onReplayVoice: () -> Unit
) {
    val isUser = message.sender == MessageSender.USER
    val bubbleShape = if (isUser) {
        RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp)
    } else {
        RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp)
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 320.dp)
                .clip(bubbleShape)
                .background(
                    if (isUser) {
                        Brush.linearGradient(
                            colors = listOf(
                                ElectricViolet.copy(alpha = 0.85f),
                                NeonSky.copy(alpha = 0.75f)
                            )
                        )
                    } else {
                        Brush.linearGradient(
                            colors = listOf(GlassCardElevated, GlassCardBg)
                        )
                    }
                )
                .border(
                    width = 1.dp,
                    color = if (isUser) NeonSky.copy(alpha = 0.45f) else NeonCyan.copy(alpha = 0.30f),
                    shape = bubbleShape
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Column {
                // Header của tin nhắn Quân: Tên + Nhãn tính cách + Nút đọc lại thành tiếng
                if (!isUser) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "QUÂN",
                                color = NeonCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(ElectricViolet.copy(alpha = 0.25f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = message.moodBadgeLabel(),
                                    color = TextSecondary,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        IconButton(
                            onClick = onReplayVoice,
                            modifier = Modifier.size(22.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Đọc lại câu này",
                                tint = NeonCyan,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                Text(
                    text = message.text,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )

                // Thẻ kết quả thực thi hành động Android thực tế (nếu có)
                message.executionResult?.let { exec ->
                    if (exec.commandType != CommandType.NONE) {
                        Spacer(modifier = Modifier.height(8.dp))
                        val statusColor = if (exec.success) EmeraldSuccess else CrimsonAlert
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(statusColor.copy(alpha = 0.14f))
                                .border(1.dp, statusColor.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (exec.success) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = statusColor,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = exec.summaryTitle,
                                    color = statusColor,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                if (exec.detailMessage.isNotBlank()) {
                                    Text(
                                        text = exec.detailMessage,
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = message.formattedTime(),
                    color = TextMuted,
                    fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}

@Composable
private fun InstalledAppsTab(
    apps: List<InstalledAppInfo>,
    isScanning: Boolean,
    onRefresh: () -> Unit,
    onLaunchApp: (InstalledAppInfo) -> Unit
) {
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var showSystemApps by rememberSaveable { mutableStateOf(false) }

    val filteredApps = remember(apps, searchQuery, showSystemApps) {
        apps.filter { app ->
            val matchesSystem = if (showSystemApps) true else !app.isSystemApp
            val matchesQuery = searchQuery.isBlank() ||
                app.appName.contains(searchQuery, ignoreCase = true) ||
                app.packageName.contains(searchQuery, ignoreCase = true)
            matchesSystem && matchesQuery
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Danh Sách Ứng Dụng Thực Tế",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Đã nhận diện ${apps.size} ứng dụng có thể mở trên máy",
                    color = NeonCyan,
                    fontSize = 12.sp
                )
            }

            IconButton(onClick = onRefresh) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Quét lại ứng dụng",
                    tint = NeonCyan
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = NeonCyan)
            },
            placeholder = {
                Text("Tìm tên ứng dụng hoặc package (VD: TikTok, youtube)...", fontSize = 13.sp)
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = GlassCardBg,
                unfocusedContainerColor = GlassCardBg,
                focusedBorderColor = NeonCyan,
                unfocusedBorderColor = GlassBorderSubtle,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            FilterChip(
                selected = !showSystemApps,
                onClick = { showSystemApps = false },
                label = { Text("Ứng dụng người dùng") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = NeonCyan.copy(alpha = 0.22f),
                    selectedLabelColor = NeonCyan
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            FilterChip(
                selected = showSystemApps,
                onClick = { showSystemApps = true },
                label = { Text("Bao gồm App Hệ thống") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = ElectricViolet.copy(alpha = 0.25f),
                    selectedLabelColor = TextPrimary
                )
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (isScanning) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Quân đang quét danh sách ứng dụng trên máy...", color = NeonCyan)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(items = filteredApps, key = { it.packageName }) { app ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(GlassCardBg)
                            .border(1.dp, GlassBorderSubtle, RoundedCornerShape(14.dp))
                            .clickable { onLaunchApp(app) }
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = app.appName,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = app.packageName,
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.Launch,
                            contentDescription = "Mở ứng dụng",
                            tint = NeonCyan
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AiAndVoiceSettingsTab(
    settings: vn.quan.trolyquan.domain.model.AiSettings,
    availableVoices: List<String>,
    selectedVoiceSummary: String,
    onSaveSettings: (vn.quan.trolyquan.domain.model.AiSettings) -> Unit,
    onTestSpeak: () -> Unit
) {
    val context = LocalContext.current
    var selectedProvider by remember(settings.provider) { mutableStateOf(settings.provider) }
    var apiKey by remember(settings.apiKey) { mutableStateOf(settings.apiKey) }
    var baseUrl by remember(settings.baseUrl) { mutableStateOf(settings.baseUrl) }
    var modelName by remember(settings.modelName) { mutableStateOf(settings.modelName) }
    var showApiKey by rememberSaveable { mutableStateOf(false) }

    var voiceAutoSpeak by remember(settings.voiceAutoSpeak) { mutableStateOf(settings.voiceAutoSpeak) }
    var voicePitch by remember(settings.voicePitch) { mutableStateOf(settings.voicePitch) }
    var voiceRate by remember(settings.voiceRate) { mutableStateOf(settings.voiceRate) }
    var preferredVoice by remember(settings.preferredVoiceName) { mutableStateOf(settings.preferredVoiceName) }
    var continuousListen by remember(settings.continuousListenAfterSpeak) {
        mutableStateOf(settings.continuousListenAfterSpeak)
    }
    var allowRoast by remember(settings.allowSlangAndRoast) { mutableStateOf(settings.allowSlangAndRoast) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Cấu Hình Trí Tuệ Nhân Tạo & Giọng Nói",
            color = TextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        // Thẻ chọn nhà cung cấp AI
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(GlassCardBg)
                .border(1.dp, GlassBorderSubtle, RoundedCornerShape(16.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "1. Nhà cung cấp Mô hình AI (Hỗ trợ đổi API linh hoạt)",
                color = NeonCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )

            AiProviderType.entries.forEach { provider ->
                val isSelected = selectedProvider == provider
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) NeonCyan.copy(alpha = 0.15f) else DeepSpaceSurface)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) NeonCyan else GlassBorderSubtle,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable {
                            selectedProvider = provider
                            baseUrl = provider.defaultBaseUrl
                            modelName = provider.defaultModel
                        }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = provider.displayName,
                            color = if (isSelected) NeonCyan else TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = provider.description,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Nút mở trang lấy API Key chính thức
            TextButton(
                onClick = {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(selectedProvider.officialKeyUrl))
                    context.startActivity(intent)
                }
            ) {
                Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = HotAmber)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Lấy API Key miễn phí tại: ${selectedProvider.officialKeyUrl}",
                    color = HotAmber,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                label = { Text("API Key (Mã hóa AES-256 trong EncryptedSharedPreferences)") },
                singleLine = true,
                visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { showApiKey = !showApiKey }) {
                        Icon(
                            imageVector = if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Hiện/Ẩn API Key",
                            tint = TextSecondary
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = GlassBorderSubtle,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = modelName,
                onValueChange = { modelName = it },
                label = { Text("Tên Model (VD: gemini-2.5-flash, llama-3.3-70b-versatile)") },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = GlassBorderSubtle,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = baseUrl,
                onValueChange = { baseUrl = it },
                label = { Text("API Base URL") },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = GlassBorderSubtle,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Thẻ tùy chỉnh tính cách & giọng nói tiếng Việt
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(GlassCardBg)
                .border(1.dp, GlassBorderSubtle, RoundedCornerShape(16.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "2. Giọng Đọc Nam Tiếng Việt & Tính Cách Quân",
                color = NeonCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )

            Text(
                text = selectedVoiceSummary,
                color = EmeraldSuccess,
                fontSize = 12.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Chế độ tính cách bộc trực / cà khịa vui", color = TextPrimary, fontSize = 14.sp)
                    Text("Bật để Quân nói chuyện kiểu anh em chí cốt, hài hước", color = TextSecondary, fontSize = 11.sp)
                }
                Switch(
                    checked = allowRoast,
                    onCheckedChange = { allowRoast = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = ObsidianBg, checkedTrackColor = NeonCyan)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Tự động đọc câu trả lời thành tiếng", color = TextPrimary, fontSize = 14.sp)
                    Text("Phát giọng nói tiếng Việt ngay khi Quân trả lời", color = TextSecondary, fontSize = 11.sp)
                }
                Switch(
                    checked = voiceAutoSpeak,
                    onCheckedChange = { voiceAutoSpeak = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = ObsidianBg, checkedTrackColor = NeonCyan)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Hội thoại rảnh tay liên tục", color = TextPrimary, fontSize = 14.sp)
                    Text("Tự động bật lại Micro sau khi Quân đọc xong câu trả lời", color = TextSecondary, fontSize = 11.sp)
                }
                Switch(
                    checked = continuousListen,
                    onCheckedChange = { continuousListen = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = ObsidianBg, checkedTrackColor = NeonCyan)
                )
            }

            Text(
                text = "Độ trầm giọng Nam (Pitch: ${"%.2f".format(voicePitch)}x — Khuyên dùng 0.85 - 0.95 cho giọng nam trầm)",
                color = TextPrimary,
                fontSize = 12.sp
            )
            Slider(
                value = voicePitch,
                onValueChange = { voicePitch = it },
                valueRange = 0.65f..1.35f,
                colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
            )

            Text(
                text = "Tốc độ nói (Rate: ${"%.2f".format(voiceRate)}x)",
                color = TextPrimary,
                fontSize = 12.sp
            )
            Slider(
                value = voiceRate,
                onValueChange = { voiceRate = it },
                valueRange = 0.75f..1.45f,
                colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
            )

            if (availableVoices.isNotEmpty()) {
                Text(
                    text = "Giọng đọc Tiếng Việt tìm thấy trên máy (${availableVoices.size}):",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    availableVoices.forEach { vName ->
                        FilterChip(
                            selected = preferredVoice == vName,
                            onClick = { preferredVoice = vName },
                            label = { Text(vName, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonCyan.copy(alpha = 0.25f),
                                selectedLabelColor = NeonCyan
                            )
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onTestSpeak,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.RecordVoiceOver, contentDescription = null, tint = NeonCyan)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Nghe thử giọng", color = NeonCyan)
                }

                Button(
                    onClick = {
                        onSaveSettings(
                            vn.quan.trolyquan.domain.model.AiSettings(
                                provider = selectedProvider,
                                apiKey = apiKey,
                                baseUrl = baseUrl,
                                modelName = modelName,
                                voiceAutoSpeak = voiceAutoSpeak,
                                voicePitch = voicePitch,
                                voiceRate = voiceRate,
                                preferredVoiceName = preferredVoice,
                                continuousListenAfterSpeak = continuousListen,
                                allowSlangAndRoast = allowRoast
                            )
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = ObsidianBg),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Lưu Cấu Hình", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SystemDiagnosticsTab(
    uiState: QuanUiState,
    hasAudioPermission: Boolean,
    hasCameraPermission: Boolean,
    hasCallPermission: Boolean,
    onRequestPermissions: () -> Unit,
    onExecuteDirectCommand: (SystemCommand) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Trạng Thái Hoạt Động & Kiểm Thử Thực Tế",
            color = TextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        // Bảng trạng thái quyền và phần cứng
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(GlassCardBg)
                .border(1.dp, GlassBorderSubtle, RoundedCornerShape(16.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("1. Kiểm tra Quyền Hệ Thống & Cảm Biến", color = NeonCyan, fontWeight = FontWeight.Bold)
            DiagnosticStatusRow("Quyền Micro (RECORD_AUDIO)", hasAudioPermission)
            DiagnosticStatusRow("Quyền Đèn Flash (CAMERA)", hasCameraPermission)
            DiagnosticStatusRow("Quyền Gọi điện (CALL_PHONE)", hasCallPermission)
            DiagnosticStatusRow("Bộ đọc Tiếng Việt (TextToSpeech vi-VN)", uiState.ttsReady)
            DiagnosticStatusRow("Đã cấu hình AI API Key", uiState.settings.apiKey.isNotBlank())

            Text(
                text = "• Số ứng dụng quét được: ${uiState.installedApps.size} ứng dụng
" +
                    "• Đèn pin hiện tại: ${if (uiState.isTorchOn) "ĐANG BẬT" else "ĐANG TẮT"}
" +
                    "• Âm lượng Media hiện tại: ${uiState.currentVolumePercent}%",
                color = TextSecondary,
                fontSize = 12.sp
            )

            if (!hasAudioPermission || !hasCameraPermission || !hasCallPermission) {
                Button(
                    onClick = onRequestPermissions,
                    colors = ButtonDefaults.buttonColors(containerColor = HotAmber, contentColor = ObsidianBg),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Cấp đầy đủ quyền Android cho Quân", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Bảng nút kiểm thử trực tiếp từng tính năng thật
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(GlassCardBg)
                .border(1.dp, GlassBorderSubtle, RoundedCornerShape(16.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "2. Bảng Kiểm Thử Nhanh Lệnh Hệ Thống (Native Action Test)",
                color = NeonCyan,
                fontWeight = FontWeight.Bold
            )

            val testButtons = listOf(
                "Test Bật Đèn Pin" to SystemCommand(type = CommandType.TORCH_CONTROL, booleanValue = true),
                "Test Tắt Đèn Pin" to SystemCommand(type = CommandType.TORCH_CONTROL, booleanValue = false),
                "Test Tăng Âm Lượng" to SystemCommand(type = CommandType.VOLUME_CONTROL, target = "UP"),
                "Test Giảm Âm Lượng" to SystemCommand(type = CommandType.VOLUME_CONTROL, target = "DOWN"),
                "Test Mở Cài Đặt" to SystemCommand(type = CommandType.OPEN_SETTINGS, target = "MAIN"),
                "Test Mở Bảng Wi-Fi" to SystemCommand(type = CommandType.WIFI_PANEL, target = "WIFI"),
                "Test Mở YouTube" to SystemCommand(type = CommandType.OPEN_APP, target = "YouTube"),
                "Test Mở Chrome" to SystemCommand(type = CommandType.OPEN_APP, target = "Chrome"),
                "Test Mở TikTok" to SystemCommand(type = CommandType.OPEN_APP, target = "TikTok")
            )

            testButtons.forEach { (label, cmd) ->
                OutlinedButton(
                    onClick = { onExecuteDirectCommand(cmd) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = NeonCyan)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = label, color = TextPrimary, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun DiagnosticStatusRow(label: String, isOk: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = TextPrimary, fontSize = 13.sp)
        Text(
            text = if (isOk) "SẴN SÀNG" else "CHƯA BẬT",
            color = if (isOk) EmeraldSuccess else HotAmber,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
    }
}

package vn.quan.trolyquan.data.system

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.Settings
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import vn.quan.trolyquan.domain.model.ActionExecutionResult
import vn.quan.trolyquan.domain.model.CommandType
import vn.quan.trolyquan.domain.model.InstalledAppInfo
import vn.quan.trolyquan.domain.model.SystemCommand

/**
 * Thực thi các thao tác điều khiển phần cứng và hệ điều hành Android thật 100%.
 * Mọi hành động đều kiểm tra quyền, kiểm tra phần cứng và báo kết quả trung thực.
 */
class SystemActionExecutor(
    private val context: Context,
    private val appsScanner: InstalledAppsScanner
) {

    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _isTorchOn = MutableStateFlow(false)
    val isTorchOn: StateFlow<Boolean> = _isTorchOn.asStateFlow()

    private var flashCameraId: String? = null

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == flashCameraId) {
                _isTorchOn.value = enabled
            }
        }
    }

    init {
        initTorchSupport()
    }

    private fun initTorchSupport() {
        try {
            val manager = cameraManager ?: return
            for (id in manager.cameraIdList) {
                val chars = manager.getCameraCharacteristics(id)
                val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                if (hasFlash) {
                    flashCameraId = id
                    break
                }
            }
            if (flashCameraId != null) {
                manager.registerTorchCallback(torchCallback, Handler(Looper.getMainLooper()))
            }
        } catch (_: Exception) {
            flashCameraId = null
        }
    }

    fun release() {
        try {
            cameraManager?.unregisterTorchCallback(torchCallback)
        } catch (_: Exception) {
        }
    }

    fun getCurrentVolumePercent(): Int {
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return ((current * 100f) / max).toInt().coerceIn(0, 100)
    }

    /**
     * Thực thi SystemCommand. Nếu lệnh nhạy cảm (như CALL_NUMBER) và chưa được xác nhận
     * (`confirmedByUser = false`), trả về trạng thái chờ người dùng bấm nút Xác nhận.
     */
    fun execute(
        command: SystemCommand,
        installedApps: List<InstalledAppInfo>,
        confirmedByUser: Boolean = false
    ): ActionExecutionResult {
        if (command.type == CommandType.NONE) {
            return ActionExecutionResult(
                success = true,
                commandType = CommandType.NONE,
                summaryTitle = "Hội thoại AI",
                detailMessage = "Không yêu cầu thao tác hệ thống"
            )
        }

        // Kiểm tra xác nhận đối với tác vụ nhạy cảm
        if ((command.requiresConfirmation || command.type == CommandType.CALL_NUMBER) && !confirmedByUser) {
            return ActionExecutionResult(
                success = false,
                commandType = command.type,
                summaryTitle = "Chờ xác nhận tác vụ nhạy cảm",
                detailMessage = "Cần bạn bấm Xác nhận trước khi thực hiện: ${command.type.displayTitle} (${command.stringValue.ifBlank { command.target }})",
                requiresUserConfirmation = true,
                pendingCommand = command
            )
        }

        return when (command.type) {
            CommandType.OPEN_APP -> executeOpenApp(command.target.ifBlank { command.stringValue }, installedApps)
            CommandType.OPEN_SETTINGS -> executeOpenSettings(command.target)
            CommandType.WIFI_PANEL -> executeOpenWifiPanel()
            CommandType.TORCH_CONTROL -> executeTorchControl(command.booleanValue ?: !_isTorchOn.value)
            CommandType.VOLUME_CONTROL -> executeVolumeControl(command.target, command.intValue)
            CommandType.DIAL_NUMBER -> executeDialNumber(command.stringValue.ifBlank { command.target })
            CommandType.CALL_NUMBER -> executeCallNumber(command.stringValue.ifBlank { command.target })
            CommandType.SET_ALARM -> executeSetAlarm(command.hour ?: 7, command.minute ?: 0, command.stringValue)
            CommandType.SET_TIMER -> executeSetTimer(command.intValue ?: 60, command.stringValue)
            CommandType.YOUTUBE_SEARCH -> executeYouTubeSearch(command.stringValue.ifBlank { command.target })
            CommandType.WEB_SEARCH -> executeWebSearch(command.stringValue.ifBlank { command.target })
            CommandType.OPEN_URL -> executeOpenUrl(command.stringValue.ifBlank { command.target })
            CommandType.NONE -> ActionExecutionResult(true, CommandType.NONE, "Trò chuyện", "")
        }
    }

    private fun executeOpenApp(
        targetQuery: String,
        installedApps: List<InstalledAppInfo>
    ): ActionExecutionResult {
        if (targetQuery.isBlank()) {
            return ActionExecutionResult(
                success = false,
                commandType = CommandType.OPEN_APP,
                summaryTitle = "Thiếu tên ứng dụng",
                detailMessage = "Không xác định được tên ứng dụng cần mở."
            )
        }

        val matchedApp = appsScanner.findBestMatchingApp(targetQuery, installedApps)
        val pm = context.packageManager

        if (matchedApp != null) {
            val launchIntent = pm.getLaunchIntentForPackage(matchedApp.packageName)
            if (launchIntent != null) {
                return try {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    ActionExecutionResult(
                        success = true,
                        commandType = CommandType.OPEN_APP,
                        summaryTitle = "Đã mở ${matchedApp.appName}",
                        detailMessage = "Package: ${matchedApp.packageName}"
                    )
                } catch (e: Exception) {
                    ActionExecutionResult(
                        success = false,
                        commandType = CommandType.OPEN_APP,
                        summaryTitle = "Không thể khởi chạy ${matchedApp.appName}",
                        detailMessage = "Lỗi hệ thống: ${e.localizedMessage ?: "SecurityException"}"
                    )
                }
            }
        }

        // Thử fallback web/intent cho YouTube hoặc Chrome nếu máy chưa cài bản đầy đủ
        val norm = targetQuery.lowercase()
        if (norm.contains("youtube")) {
            return executeOpenUrl("https://m.youtube.com")
        }
        if (norm.contains("chrome") || norm.contains("trình duyệt") || norm.contains("google")) {
            return executeOpenUrl("https://www.google.com")
        }

        return ActionExecutionResult(
            success = false,
            commandType = CommandType.OPEN_APP,
            summaryTitle = "Chưa cài đặt "$targetQuery"",
            detailMessage = "Đã quét ${installedApps.size} ứng dụng trên máy nhưng không tìm thấy "$targetQuery". Quân không giả vờ mở ứng dụng chưa cài!"
        )
    }

    private fun executeOpenSettings(target: String): ActionExecutionResult {
        val action = when (target.uppercase()) {
            "WIFI" -> Settings.ACTION_WIFI_SETTINGS
            "BLUETOOTH" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "DISPLAY" -> Settings.ACTION_DISPLAY_SETTINGS
            "SOUND" -> Settings.ACTION_SOUND_SETTINGS
            "LOCATION" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "BATTERY" -> Intent.ACTION_POWER_USAGE_SUMMARY
            "APP_DETAILS" -> Settings.ACTION_APPLICATION_DETAILS_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }

        return try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (action == Settings.ACTION_APPLICATION_DETAILS_SETTINGS) {
                    data = Uri.fromParts("package", context.packageName, null)
                }
            }
            context.startActivity(intent)
            ActionExecutionResult(
                success = true,
                commandType = CommandType.OPEN_SETTINGS,
                summaryTitle = "Đã mở Cài đặt ($target)",
                detailMessage = "Intent: $action"
            )
        } catch (e: Exception) {
            // Fallback về màn hình cài đặt chính
            try {
                val fallback = Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(fallback)
                ActionExecutionResult(
                    success = true,
                    commandType = CommandType.OPEN_SETTINGS,
                    summaryTitle = "Đã mở Cài đặt hệ thống",
                    detailMessage = "Intent: android.settings.SETTINGS"
                )
            } catch (ex: Exception) {
                ActionExecutionResult(
                    success = false,
                    commandType = CommandType.OPEN_SETTINGS,
                    summaryTitle = "Lỗi mở Cài đặt",
                    detailMessage = ex.localizedMessage ?: "Không thể mở Settings"
                )
            }
        }
    }

    private fun executeOpenWifiPanel(): ActionExecutionResult {
        return try {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                Intent(Settings.Panel.ACTION_WIFI)
            } else {
                Intent(Settings.ACTION_WIFI_SETTINGS)
            }.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionExecutionResult(
                success = true,
                commandType = CommandType.WIFI_PANEL,
                summaryTitle = "Đã mở bảng điều khiển Wi-Fi",
                detailMessage = "Trên Android 10+, hệ điều hành yêu cầu người dùng gạt công tắc Wi-Fi trực tiếp trên Panel bảo mật."
            )
        } catch (e: Exception) {
            executeOpenSettings("WIFI")
        }
    }

    private fun executeTorchControl(enable: Boolean): ActionExecutionResult {
        val manager = cameraManager
        val camId = flashCameraId
        if (manager == null || camId == null) {
            return ActionExecutionResult(
                success = false,
                commandType = CommandType.TORCH_CONTROL,
                summaryTitle = "Thiết bị không có đèn Flash",
                detailMessage = "CameraManager không tìm thấy cụm đèn Flash nào trên thiết bị này."
            )
        }

        return try {
            manager.setTorchMode(camId, enable)
            _isTorchOn.value = enable
            ActionExecutionResult(
                success = true,
                commandType = CommandType.TORCH_CONTROL,
                summaryTitle = if (enable) "Đã BẬT đèn pin" else "Đã TẮT đèn pin",
                detailMessage = "Camera ID: $camId • TorchMode = $enable"
            )
        } catch (e: Exception) {
            ActionExecutionResult(
                success = false,
                commandType = CommandType.TORCH_CONTROL,
                summaryTitle = "Không thể điều khiển đèn pin",
                detailMessage = "Lỗi CameraManager: ${e.localizedMessage ?: "Hãy kiểm tra quyền Camera hoặc đóng ứng dụng máy ảnh đang chạy"}"
            )
        }
    }

    private fun executeVolumeControl(mode: String, levelPercent: Int?): ActionExecutionResult {
        return try {
            val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val beforeVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)

            when (mode.uppercase()) {
                "UP" -> {
                    val step = (maxVol * 0.20f).toInt().coerceAtLeast(1)
                    val targetVol = (beforeVol + step).coerceAtMost(maxVol)
                    audioManager.setStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        targetVol,
                        AudioManager.FLAG_SHOW_UI
                    )
                }
                "DOWN" -> {
                    val step = (maxVol * 0.20f).toInt().coerceAtLeast(1)
                    val targetVol = (beforeVol - step).coerceAtLeast(0)
                    audioManager.setStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        targetVol,
                        AudioManager.FLAG_SHOW_UI
                    )
                }
                "MAX" -> {
                    audioManager.setStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        maxVol,
                        AudioManager.FLAG_SHOW_UI
                    )
                }
                "MUTE" -> {
                    audioManager.setStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        0,
                        AudioManager.FLAG_SHOW_UI
                    )
                }
                "SET" -> {
                    val pct = (levelPercent ?: 50).coerceIn(0, 100)
                    val targetVol = ((pct / 100f) * maxVol).toInt().coerceIn(0, maxVol)
                    audioManager.setStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        targetVol,
                        AudioManager.FLAG_SHOW_UI
                    )
                }
                else -> {
                    audioManager.adjustStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        AudioManager.ADJUST_RAISE,
                        AudioManager.FLAG_SHOW_UI
                    )
                }
            }

            val afterVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            val afterPct = ((afterVol * 100f) / maxVol).toInt()
            ActionExecutionResult(
                success = true,
                commandType = CommandType.VOLUME_CONTROL,
                summaryTitle = "Âm lượng Media: $afterPct% ($afterVol/$maxVol)",
                detailMessage = "Đã điều chỉnh từ mức $beforeVol/$maxVol sang $afterVol/$maxVol"
            )
        } catch (e: SecurityException) {
            ActionExecutionResult(
                success = false,
                commandType = CommandType.VOLUME_CONTROL,
                summaryTitle = "Bị chặn bởi chế độ Không làm phiền (DND)",
                detailMessage = "Thiết bị đang bật chế độ Không làm phiền nghiêm ngặt: ${e.localizedMessage}"
            )
        } catch (e: Exception) {
            ActionExecutionResult(
                success = false,
                commandType = CommandType.VOLUME_CONTROL,
                summaryTitle = "Lỗi chỉnh âm lượng",
                detailMessage = e.localizedMessage ?: "AudioManager error"
            )
        }
    }

    private fun executeDialNumber(phoneNumber: String): ActionExecutionResult {
        val cleanPhone = phoneNumber.replace(Regex("[^\\d+*#]"), "")
        if (cleanPhone.isBlank()) {
            return ActionExecutionResult(
                success = false,
                commandType = CommandType.DIAL_NUMBER,
                summaryTitle = "Số điện thoại trống",
                detailMessage = "Không tìm thấy số điện thoại hợp lệ để quay số."
            )
        }
        return try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanPhone")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionExecutionResult(
                success = true,
                commandType = CommandType.DIAL_NUMBER,
                summaryTitle = "Đã mở bàn phím số: $cleanPhone",
                detailMessage = "Intent.ACTION_DIAL (tel:$cleanPhone)"
            )
        } catch (e: Exception) {
            ActionExecutionResult(
                success = false,
                commandType = CommandType.DIAL_NUMBER,
                summaryTitle = "Không thể mở trình gọi điện",
                detailMessage = e.localizedMessage ?: "Lỗi trình quay số"
            )
        }
    }

    private fun executeCallNumber(phoneNumber: String): ActionExecutionResult {
        val cleanPhone = phoneNumber.replace(Regex("[^\\d+*#]"), "")
        if (cleanPhone.isBlank()) {
            return ActionExecutionResult(
                success = false,
                commandType = CommandType.CALL_NUMBER,
                summaryTitle = "Số điện thoại không hợp lệ",
                detailMessage = "Không thể thực hiện cuộc gọi vì thiếu số điện thoại."
            )
        }

        val hasCallPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        return if (hasCallPermission) {
            try {
                val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$cleanPhone")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                ActionExecutionResult(
                    success = true,
                    commandType = CommandType.CALL_NUMBER,
                    summaryTitle = "Đang gọi trực tiếp: $cleanPhone",
                    detailMessage = "Đã được người dùng xác nhận • Intent.ACTION_CALL"
                )
            } catch (e: Exception) {
                executeDialNumber(cleanPhone)
            }
        } else {
            // Nếu chưa cấp quyền CALL_PHONE, chuyển sang mở bàn phím quay số an toàn
            val dialRes = executeDialNumber(cleanPhone)
            dialRes.copy(
                summaryTitle = "Mở trình quay số $cleanPhone (Chưa cấp quyền gọi thẳng)",
                detailMessage = "Ứng dụng chưa có quyền CALL_PHONE nên đã mở sẵn số $cleanPhone trên trình gọi điện để bạn bấm nút Gọi."
            )
        }
    }

    private fun executeSetAlarm(hour: Int, minute: Int, label: String): ActionExecutionResult {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
                putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
                putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "Báo thức Trợ Lý Quân" })
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionExecutionResult(
                success = true,
                commandType = CommandType.SET_ALARM,
                summaryTitle = "Đã đặt báo thức %02d:%02d".format(hour, minute),
                detailMessage = "Nhãn: ${label.ifBlank { "Báo thức Trợ Lý Quân" }}"
            )
        } catch (e: Exception) {
            ActionExecutionResult(
                success = false,
                commandType = CommandType.SET_ALARM,
                summaryTitle = "Không tìm thấy ứng dụng Đồng hồ",
                detailMessage = "Thiết bị không có ứng dụng nhận AlarmClock Intent: ${e.localizedMessage}"
            )
        }
    }

    private fun executeSetTimer(seconds: Int, label: String): ActionExecutionResult {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds.coerceAtLeast(5))
                putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "Hẹn giờ Trợ Lý Quân" })
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionExecutionResult(
                success = true,
                commandType = CommandType.SET_TIMER,
                summaryTitle = "Đã đặt hẹn giờ ${seconds}s",
                detailMessage = "Intent: AlarmClock.ACTION_SET_TIMER"
            )
        } catch (e: Exception) {
            ActionExecutionResult(
                success = false,
                commandType = CommandType.SET_TIMER,
                summaryTitle = "Không thể đặt hẹn giờ",
                detailMessage = e.localizedMessage ?: "Lỗi AlarmClock Timer"
            )
        }
    }

    private fun executeYouTubeSearch(query: String): ActionExecutionResult {
        val encoded = Uri.encode(query.ifBlank { "nhạc trẻ" })
        return try {
            val intent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.youtube.com/results?search_query=$encoded")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionExecutionResult(
                success = true,
                commandType = CommandType.YOUTUBE_SEARCH,
                summaryTitle = "Đã mở YouTube tìm: "$query"",
                detailMessage = "Query: $query"
            )
        } catch (e: Exception) {
            ActionExecutionResult(
                success = false,
                commandType = CommandType.YOUTUBE_SEARCH,
                summaryTitle = "Lỗi mở tìm kiếm YouTube",
                detailMessage = e.localizedMessage ?: "Không thể mở YouTube"
            )
        }
    }

    private fun executeWebSearch(query: String): ActionExecutionResult {
        return try {
            val webIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra(SearchManager.QUERY, query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webIntent)
            ActionExecutionResult(
                success = true,
                commandType = CommandType.WEB_SEARCH,
                summaryTitle = "Đã tìm Google: "$query"",
                detailMessage = "Intent.ACTION_WEB_SEARCH"
            )
        } catch (_: Exception) {
            val encoded = Uri.encode(query)
            executeOpenUrl("https://www.google.com/search?q=$encoded")
        }
    }

    private fun executeOpenUrl(rawUrl: String): ActionExecutionResult {
        val validUrl = if (rawUrl.startsWith("http://") || rawUrl.startsWith("https://")) {
            rawUrl
        } else {
            "https://$rawUrl"
        }
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(validUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ActionExecutionResult(
                success = true,
                commandType = CommandType.OPEN_URL,
                summaryTitle = "Đã mở liên kết Web",
                detailMessage = validUrl
            )
        } catch (e: Exception) {
            ActionExecutionResult(
                success = false,
                commandType = CommandType.OPEN_URL,
                summaryTitle = "Không thể mở trang web",
                detailMessage = e.localizedMessage ?: validUrl
            )
        }
    }
}

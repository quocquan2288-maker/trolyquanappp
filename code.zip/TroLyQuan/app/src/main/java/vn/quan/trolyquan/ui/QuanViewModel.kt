package vn.quan.trolyquan.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import vn.quan.trolyquan.data.ai.AiApiService
import vn.quan.trolyquan.data.local.SecurePreferencesRepository
import vn.quan.trolyquan.data.system.InstalledAppsScanner
import vn.quan.trolyquan.data.system.SystemActionExecutor
import vn.quan.trolyquan.data.voice.VoiceAssistantManager
import vn.quan.trolyquan.domain.model.ActionExecutionResult
import vn.quan.trolyquan.domain.model.AiSettings
import vn.quan.trolyquan.domain.model.AssistantState
import vn.quan.trolyquan.domain.model.ChatMessage
import vn.quan.trolyquan.domain.model.CommandType
import vn.quan.trolyquan.domain.model.InstalledAppInfo
import vn.quan.trolyquan.domain.model.MessageSender
import vn.quan.trolyquan.domain.model.SystemCommand

data class QuanUiState(
    val assistantState: AssistantState = AssistantState.IDLE,
    val messages: List<ChatMessage> = emptyList(),
    val installedApps: List<InstalledAppInfo> = emptyList(),
    val isScanningApps: Boolean = false,
    val settings: AiSettings = AiSettings(),
    val isTorchOn: Boolean = false,
    val currentVolumePercent: Int = 50,
    val isListening: Boolean = false,
    val isSpeaking: Boolean = false,
    val partialSpeechText: String = "",
    val audioAmplitude: Float = 0.08f,
    val ttsReady: Boolean = false,
    val availableVietnameseVoices: List<String> = emptyList(),
    val selectedVoiceSummary: String = "",
    val pendingConfirmationCommand: SystemCommand? = null,
    val pendingConfirmationDescription: String = "",
    val lastDiagnosticBanner: String? = null
)

/**
 * ViewModel trung tâm điều phối toàn bộ hoạt động của TRỢ LÝ QUÂN:
 * Nhận diện giọng nói <-> AI Gemini/Groq/Local <-> Thực thi Android Intent/API thật <-> Phát giọng nói TTS.
 */
class QuanViewModel(application: Application) : AndroidViewModel(application) {

    private val prefsRepo = SecurePreferencesRepository(application)
    private val appsScanner = InstalledAppsScanner(application)
    private val systemExecutor = SystemActionExecutor(application, appsScanner)
    private val aiApiService = AiApiService()

    private lateinit var voiceManager: VoiceAssistantManager

    private val _uiState = MutableStateFlow(QuanUiState())
    val uiState: StateFlow<QuanUiState> = _uiState.asStateFlow()

    init {
        val savedSettings = prefsRepo.loadSettings()
        val savedHistory = prefsRepo.loadChatHistory().ifEmpty {
            listOf(
                ChatMessage(
                    sender = MessageSender.QUAN,
                    text = "Chào đại ca! Tôi là Quân — trợ lý AI thực chiến trên máy Android của ông đây. Cần mở TikTok, bật YouTube, mở Chrome, bật đèn pin, chỉnh âm lượng hay hỏi han gì thì bấm nút Micro hoặc gõ bên dưới nhé!",
                    moodTag = "NHIET_TINH"
                )
            )
        }

        _uiState.update {
            it.copy(
                settings = savedSettings,
                messages = savedHistory,
                currentVolumePercent = systemExecutor.getCurrentVolumePercent()
            )
        }

        initVoiceEngine(savedSettings)
        observeHardwareState()
        refreshInstalledApps()
    }

    private fun initVoiceEngine(initialSettings: AiSettings) {
        voiceManager = VoiceAssistantManager(
            context = getApplication(),
            onFinalSpeechResult = { recognizedText ->
                submitUserMessage(recognizedText, triggeredByVoice = true)
            },
            onSpeechErrorEvent = { errorMsg ->
                _uiState.update {
                    it.copy(
                        assistantState = AssistantState.ERROR,
                        lastDiagnosticBanner = errorMsg
                    )
                }
                viewModelScope.launch {
                    delay(3500)
                    if (_uiState.value.assistantState == AssistantState.ERROR) {
                        _uiState.update { state -> state.copy(assistantState = AssistantState.IDLE) }
                    }
                }
            },
            onTtsFinishedEvent = {
                val currentSettings = _uiState.value.settings
                if (currentSettings.continuousListenAfterSpeak) {
                    voiceManager.startListening()
                } else {
                    _uiState.update { it.copy(assistantState = AssistantState.IDLE) }
                }
            }
        )

        viewModelScope.launch {
            voiceManager.isListening.collect { listening ->
                _uiState.update { state ->
                    val nextState = when {
                        listening -> AssistantState.LISTENING
                        state.assistantState == AssistantState.LISTENING -> AssistantState.IDLE
                        else -> state.assistantState
                    }
                    state.copy(isListening = listening, assistantState = nextState)
                }
            }
        }

        viewModelScope.launch {
            voiceManager.isSpeaking.collect { speaking ->
                _uiState.update { state ->
                    val nextState = when {
                        speaking -> AssistantState.SPEAKING
                        state.assistantState == AssistantState.SPEAKING -> AssistantState.IDLE
                        else -> state.assistantState
                    }
                    state.copy(isSpeaking = speaking, assistantState = nextState)
                }
            }
        }

        viewModelScope.launch {
            voiceManager.partialTranscript.collect { partial ->
                _uiState.update { it.copy(partialSpeechText = partial) }
            }
        }

        viewModelScope.launch {
            voiceManager.audioAmplitude.collect { amp ->
                _uiState.update { it.copy(audioAmplitude = amp) }
            }
        }

        viewModelScope.launch {
            voiceManager.ttsReady.collect { ready ->
                _uiState.update { it.copy(ttsReady = ready) }
                if (ready) {
                    voiceManager.configureBestVietnameseMaleVoice(
                        preferredVoiceName = initialSettings.preferredVoiceName,
                        pitch = initialSettings.voicePitch,
                        rate = initialSettings.voiceRate
                    )
                }
            }
        }

        viewModelScope.launch {
            voiceManager.availableVietnameseVoices.collect { voices ->
                _uiState.update { it.copy(availableVietnameseVoices = voices) }
            }
        }

        viewModelScope.launch {
            voiceManager.selectedVoiceSummary.collect { summary ->
                _uiState.update { it.copy(selectedVoiceSummary = summary) }
            }
        }
    }

    private fun observeHardwareState() {
        viewModelScope.launch {
            systemExecutor.isTorchOn.collect { torchOn ->
                _uiState.update { it.copy(isTorchOn = torchOn) }
            }
        }
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            _uiState.update { it.copy(isScanningApps = true) }
            val apps = appsScanner.scanInstalledLaunchableApps()
            _uiState.update {
                it.copy(
                    installedApps = apps,
                    isScanningApps = false,
                    currentVolumePercent = systemExecutor.getCurrentVolumePercent()
                )
            }
        }
    }

    /**
     * Xử lý khi người dùng bấm vào Quả cầu AI hoặc nút Micro lớn:
     * - Nếu Quân đang nói -> Ngắt lời ngay lập tức và chuyển sang nghe.
     * - Nếu đang nghe -> Dừng nghe.
     * - Nếu đang rảnh -> Bắt đầu thu âm tiếng Việt.
     */
    fun onMicOrOrbClicked(hasAudioPermission: Boolean, onRequestAudioPermission: () -> Unit) {
        if (_uiState.value.isSpeaking) {
            voiceManager.stopSpeaking()
            if (hasAudioPermission) {
                voiceManager.startListening()
            }
            return
        }

        if (!hasAudioPermission) {
            onRequestAudioPermission()
            return
        }

        if (_uiState.value.isListening) {
            voiceManager.stopListening()
        } else {
            _uiState.update { it.copy(lastDiagnosticBanner = null) }
            voiceManager.startListening()
        }
    }

    fun stopQuanSpeaking() {
        voiceManager.stopSpeaking()
        _uiState.update { it.copy(assistantState = AssistantState.IDLE) }
    }

    /**
     * Gửi câu lệnh của người dùng (từ giọng nói hoặc bàn phím) cho Quân xử lý.
     */
    fun submitUserMessage(rawText: String, triggeredByVoice: Boolean = false) {
        val cleanText = rawText.trim()
        if (cleanText.isBlank()) return

        voiceManager.stopSpeaking()
        if (_uiState.value.isListening) {
            voiceManager.stopListening()
        }

        val userMessage = ChatMessage(
            sender = MessageSender.USER,
            text = cleanText
        )

        val historySnapshot = _uiState.value.messages
        val updatedWithUser = historySnapshot + userMessage

        _uiState.update {
            it.copy(
                messages = updatedWithUser,
                assistantState = AssistantState.THINKING,
                partialSpeechText = "",
                lastDiagnosticBanner = null
            )
        }
        prefsRepo.saveChatHistory(updatedWithUser)

        viewModelScope.launch {
            val currentState = _uiState.value
            val aiResponse = aiApiService.generateAssistantTurn(
                userText = cleanText,
                conversationHistory = historySnapshot,
                settings = currentState.settings,
                installedApps = currentState.installedApps,
                torchCurrentlyOn = currentState.isTorchOn,
                currentVolumePercent = systemExecutor.getCurrentVolumePercent()
            )

            var executionResult: ActionExecutionResult? = null
            var finalReplyText = aiResponse.replyText

            if (aiResponse.command.type != CommandType.NONE) {
                _uiState.update { it.copy(assistantState = AssistantState.EXECUTING) }
                executionResult = systemExecutor.execute(
                    command = aiResponse.command,
                    installedApps = _uiState.value.installedApps,
                    confirmedByUser = false
                )

                // Nếu cần người dùng xác nhận (VD: Gọi điện thoại)
                if (executionResult.requiresUserConfirmation && executionResult.pendingCommand != null) {
                    _uiState.update {
                        it.copy(
                            pendingConfirmationCommand = executionResult.pendingCommand,
                            pendingConfirmationDescription = executionResult.detailMessage
                        )
                    }
                } else if (!executionResult.success) {
                    // Báo lỗi trung thực nếu lệnh hệ thống thất bại (ví dụ app chưa cài)
                    finalReplyText = "${aiResponse.replyText}
(${executionResult.summaryTitle}: ${executionResult.detailMessage})"
                }
            }

            val quanMessage = ChatMessage(
                sender = MessageSender.QUAN,
                text = finalReplyText,
                moodTag = aiResponse.moodTag,
                command = aiResponse.command.takeIf { it.type != CommandType.NONE },
                executionResult = executionResult
            )

            val newMessages = _uiState.value.messages + quanMessage
            _uiState.update {
                it.copy(
                    messages = newMessages,
                    currentVolumePercent = systemExecutor.getCurrentVolumePercent(),
                    lastDiagnosticBanner = aiResponse.errorDiagnostic,
                    assistantState = if (it.settings.voiceAutoSpeak || triggeredByVoice) {
                        AssistantState.SPEAKING
                    } else {
                        AssistantState.IDLE
                    }
                )
            }
            prefsRepo.saveChatHistory(newMessages)

            if (_uiState.value.settings.voiceAutoSpeak || triggeredByVoice) {
                speakMessage(finalReplyText)
            }
        }
    }

    fun speakMessage(text: String) {
        val s = _uiState.value.settings
        voiceManager.speak(
            text = text,
            pitch = s.voicePitch,
            rate = s.voiceRate,
            preferredVoiceName = s.preferredVoiceName
        )
    }

    fun confirmPendingSensitiveAction() {
        val pending = _uiState.value.pendingConfirmationCommand ?: return
        _uiState.update {
            it.copy(
                pendingConfirmationCommand = null,
                pendingConfirmationDescription = "",
                assistantState = AssistantState.EXECUTING
            )
        }

        val result = systemExecutor.execute(
            command = pending,
            installedApps = _uiState.value.installedApps,
            confirmedByUser = true
        )

        val confirmMsg = ChatMessage(
            sender = MessageSender.QUAN,
            text = if (result.success) {
                "Đã xác nhận và thực thi xong: ${result.summaryTitle}!"
            } else {
                "Không thực hiện được sau khi xác nhận: ${result.detailMessage}"
            },
            moodTag = "NGHIEM_TUC",
            command = pending,
            executionResult = result
        )

        val updated = _uiState.value.messages + confirmMsg
        _uiState.update {
            it.copy(
                messages = updated,
                assistantState = AssistantState.IDLE
            )
        }
        prefsRepo.saveChatHistory(updated)
    }

    fun cancelPendingSensitiveAction() {
        _uiState.update {
            it.copy(
                pendingConfirmationCommand = null,
                pendingConfirmationDescription = "",
                assistantState = AssistantState.IDLE
            )
        }
        val cancelMsg = ChatMessage(
            sender = MessageSender.QUAN,
            text = "Ok đại ca, đã hủy thao tác nhạy cảm đó rồi nhé. An toàn là trên hết!",
            moodTag = "THANG_THAN"
        )
        val updated = _uiState.value.messages + cancelMsg
        _uiState.update { it.copy(messages = updated) }
        prefsRepo.saveChatHistory(updated)
    }

    fun executeDirectCommand(command: SystemCommand) {
        val result = systemExecutor.execute(
            command = command,
            installedApps = _uiState.value.installedApps,
            confirmedByUser = true
        )
        _uiState.update {
            it.copy(
                currentVolumePercent = systemExecutor.getCurrentVolumePercent(),
                lastDiagnosticBanner = "${result.summaryTitle} • ${result.detailMessage}"
            )
        }
    }

    fun toggleTorchDirect() {
        val target = !_uiState.value.isTorchOn
        val result = systemExecutor.execute(
            command = SystemCommand(type = CommandType.TORCH_CONTROL, booleanValue = target),
            installedApps = _uiState.value.installedApps,
            confirmedByUser = true
        )
        if (!result.success) {
            _uiState.update { it.copy(lastDiagnosticBanner = result.detailMessage) }
        }
    }

    fun launchInstalledAppDirect(appInfo: InstalledAppInfo) {
        submitUserMessage("Mở ứng dụng ${appInfo.appName}")
    }

    fun updateSettings(newSettings: AiSettings) {
        prefsRepo.saveSettings(newSettings)
        voiceManager.configureBestVietnameseMaleVoice(
            preferredVoiceName = newSettings.preferredVoiceName,
            pitch = newSettings.voicePitch,
            rate = newSettings.voiceRate
        )
        _uiState.update {
            it.copy(
                settings = newSettings,
                lastDiagnosticBanner = "Đã lưu cấu hình bảo mật thành công!"
            )
        }
    }

    fun toggleVoiceAutoSpeak() {
        val current = _uiState.value.settings
        val updated = current.copy(voiceAutoSpeak = !current.voiceAutoSpeak)
        updateSettings(updated)
        if (!updated.voiceAutoSpeak) {
            voiceManager.stopSpeaking()
        }
    }

    fun clearHistory() {
        prefsRepo.clearChatHistory()
        val resetGreeting = ChatMessage(
            sender = MessageSender.QUAN,
            text = "Đã dọn sạch lịch sử trò chuyện rồi nhé ông tướng! Giờ muốn sai bảo gì tiếp nào?",
            moodTag = "CA_KHIA"
        )
        _uiState.update { it.copy(messages = listOf(resetGreeting)) }
        prefsRepo.saveChatHistory(listOf(resetGreeting))
    }

    fun dismissDiagnosticBanner() {
        _uiState.update { it.copy(lastDiagnosticBanner = null) }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.release()
        systemExecutor.release()
    }
}
